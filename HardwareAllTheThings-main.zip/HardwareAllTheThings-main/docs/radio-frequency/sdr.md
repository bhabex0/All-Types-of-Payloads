# SDR

### Frequency Independent SDR-based Signal Understanding and Reverse Engineering

[https://github.com/ainfosec/FISSURE](https://github.com/ainfosec/FISSURE)