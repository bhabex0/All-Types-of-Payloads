# Arduino

## 

* [Logic Analyzer for Arduino, AVR, ESP8266 and STM32 - aster94/logic-analyzer](https://github.com/aster94/logic-analyzer)
* [JTAGulator-like for Arduino, Teensy, STM32 Bluepill, Texas Instruments Tiva and RaspberryPi - cyphunk/JTAGenum](https://github.com/cyphunk/JTAGenum)


## References

* []()