# HydraFlash

> Designed to dump Flash NAND chips


## Usage

* [hydrabus/DumpFlash-Hydrabus](https://github.com/hydrabus/DumpFlash-Hydrabus)
    ```ps1
    pip install git+https://github.com/hydrabus/DumpFlash-Hydrabus
    python2 DumpFlash.py -d /dev/hydrabus -i
    ```


## References

* [Hydrabus NAND Flash shield - hydrabus/HydraFlash](https://github.com/hydrabus/HydraFlash)