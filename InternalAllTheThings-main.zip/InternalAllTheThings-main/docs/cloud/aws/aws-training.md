# AWS - Training

* [bishopfox/CloudFoxable](https://cloudfoxable.bishopfox.com/): A Gamified Cloud Hacking Sandbox
* [ine-labs/AWSGoat](https://github.com/ine-labs/AWSGoat) : A Damn Vulnerable AWS Infrastructure
* [m6a-UdS/dvca](https://github.com/m6a-UdS/dvca) - A demonstration project to show how to do privilege escalation on AWS
* [nccgroup/sadcloud](https://github.com/nccgroup/sadcloud) -  A tool for standing up (and tearing down!) purposefully insecure cloud infrastructure
* [0xdabbad00/Flaws](http://flaws.cloud) - Several level of challenges around AWS
* [RhinoSecurityLabs/cloudgoat](https://github.com/RhinoSecurityLabs/cloudgoat) - "Vulnerable by Design" AWS deployment tool